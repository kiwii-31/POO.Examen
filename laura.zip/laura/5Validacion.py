#Ejercicio 5 - Validación de cumplimiento de contrato 
#Situación: Queremos implementar un tipo de sensor que debe enviar datos al servidor.
#Nos olvidamos de cumplir el contrato abstracto.

#Consigna:        
#1. ¿Por qué este código no funciona al intentar crear una instancia de `SensorTemperatura`?
#2. Corregilo agregando la implementación que falta, sin modificar la clase base.
#3. Mostrá cómo funciona correctamente luego.

#Código base:

from abc import ABC, abstractmethod

class Sensor(ABC):
    @abstractmethod
    def enviar_datos(self):
        pass

class SensorTemperatura(Sensor):
    def leer_temperatura(self):
        print("Leyendo temperatura: 23°C")

    #2. agregamos la implementacion
    #metodo para el envio de datos
    def enviar_datos(self):
        print("Enviando datos de temperatura al servidor") #enviamos los datos

#1.el codigo no funciona al intentar crear una instancia de SensorTemperatura porque no esta implementado el 
#metodo enviar_datos, que es un metodo abstracto

#3.funciona de esta manera, primero enviamos los datos 
sensor_temperatura = SensorTemperatura() #instanciamos el sensor
#se lee los datos(atributos) enviados
sensor_temperatura.leer_temperatura()
sensor_temperatura.enviar_datos()



