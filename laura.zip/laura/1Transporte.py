#Ejercicio 1 – Simulador de Transporte Urbano 
#Situación: Queremos modelar un sistema de transporte para una ciudad. Hay distintos vehículos,
# pero todos comparten algunas funciones básicas.

#Consigna:
#1. Crear una función `simular_viaje(transporte, metros)` que reciba un `Transporte` y lo haga 
# avanzar y detener.
#2. Instanciar ambos transportes y usarlos en esa función.

#CODIGO BASE:

from abc import ABC, abstractmethod

class Transporte(ABC):
    @abstractmethod 
    def avanzar(self, metros):
        pass

    @abstractmethod
    def detener(self):
        pass

class Colectivo(Transporte):
    def avanzar(self, metros):
        print(f"El colectivo avanza {metros} metros por la avenida principal.")

    def detener(self):
        print("El colectivo detiene su marcha en la próxima parada.")

class Subte(Transporte):
    def avanzar(self, metros):
        print(f"El subte recorre {metros} metros por túnel.")

    def detener(self):
        print("El subte frena en la estación correspondiente.")

#definimos la funcion simular viaje, con los atributos transporte y metros
def simular_viaje(transporte, metros): 
    #llamamos a los metodos avanzar y detener
    transporte.avanzar(metros) 
    transporte.detener()

# Instanciamos los transportes
colectivo = Colectivo() #instanciamos el colectivo
subte = Subte() #instanciamos el subte

# Simular viajes
simular_viaje(colectivo, 100) #el colectivo va a avanzar 100 metros
simular_viaje(subte, 700) #y va a recorrer 700 metros
        
