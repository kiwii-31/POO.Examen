#Ejercicio 3 – Sistema de Alerta de Eventos
#Situación: Distintos sistemas envían alertas. Queremos asegurar que todos implementen un
#método `enviar_alerta()`, sin importar cómo lo hagan.

#Consigna:
#Crear una función que reciba una lista de objetos `Alertable` y les envíe un mismo mensaje.
#Mostrar cómo el mismo mensaje se procesa de forma distinta.

#Código base:
from abc import ABC, abstractmethod

class Alertable(ABC): 
    @abstractmethod
    def enviar_alerta(self, mensaje):
        pass

class SistemaMeteorologico(Alertable):
    def enviar_alerta(self, mensaje):
        print(f" Alerta meteorológica: {mensaje.upper()}")

class SistemaSeguridad(Alertable):
    def enviar_alerta(self, mensaje):
        print(f" Alerta de seguridad: {mensaje.capitalize()}")

# Crear una funcion(Metodo) que reciba la lista Alertable y les envie un mismo mensaje
def enviar_alertas(alertables, mensaje):
    for alertable in alertables: #recorremos la lista
        alertable.enviar_alerta(mensaje) #enviamos el mensaje

#hacemos la lista, para poder instanciar todos los clases de Alertable
alertables = [
    SistemaMeteorologico(), 
    SistemaSeguridad()
]

#mensaje = input("Ingrese el mensaje: ") 
mensaje = "Importante" 
enviar_alertas(alertables, mensaje) #se envia el mensaje y se recorre la listaa