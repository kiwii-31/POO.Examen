#Ejercicio 2 – Registro de Trabajadores Freelance
#Situación: Queremos administrar trabajadores freelance que pueden ser diseñadores o
#programadores. Todos tienen nombre y una tarifa por hora.

#Consigna:
#Crear una lista de freelancers mixtos y mostrar el pago que recibe cada uno al trabajar 15 horas.
#Imprimir un resumen: '{nombre} cobra ${total}'.

#Código base:

from abc import ABC, abstractmethod

class Freelancer(ABC):
    def __init__(self, nombre, tarifa_hora):
        self.nombre = nombre
        self.tarifa = tarifa_hora

    @abstractmethod
    def calcular_pago(self, horas):
        pass

    def mostrar_info(self):
        print(f"{self.nombre} cobra ${self.calcular_pago(15)}")

class Diseñador(Freelancer):
    def calcular_pago(self, horas):
        return self.tarifa * horas * 1.10

class Programador(Freelancer):
    def calcular_pago(self, horas):
        return self.tarifa * horas

# creamos una lista de freelancers mixtos
freelancers = [
    Diseñador("Laura", 35),
    Programador("Ana", 100),
    Diseñador("Martin", 20),
    Programador("Rodrigo", 45)
]

# se muestra el pago que recibe cada uno al trabajar 15 horas
for freelancer in freelancers: #se recorre la lista
    freelancer.mostrar_info() #y se llama al metodo(funcion)