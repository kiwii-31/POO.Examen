#Ejercicio 4 – Biblioteca Multimedia
#Situación: Una biblioteca digital contiene libros, películas y audios. Algunos materiales se
#pueden imprimir, otros se pueden reproducir.

#Consigna:
#Crear una lista con distintas obras y aplicar los métodos según corresponda (solo imprimir,
#solo reproducir, o ambos).

#Código base:

from abc import ABC, abstractmethod

class Imprimible(ABC):
    @abstractmethod
    def imprimir(self):
        pass

class Reproducible(ABC):
    @abstractmethod
    def reproducir(self):
        pass

class Libro(Imprimible):
    def __init__(self, titulo):
        self.titulo = titulo

    def imprimir(self):
        print(f" Imprimiendo el libro: {self.titulo}")

class Pelicula(Reproducible):
    def __init__(self, titulo):
        self.titulo = titulo
    def reproducir(self):
        print(f" Reproduciendo la película: {self.titulo}")

class Audiolibro(Imprimible, Reproducible):
    def __init__(self, titulo):
        self.titulo = titulo

    def imprimir(self):
        print(f" Imprimiendo portada de audiolibro: {self.titulo}")

    def reproducir(self):
        print(f" Reproduciendo audio: {self.titulo}")

# Crear una lista con distintas obras de Harry Potter
obras = [
    Libro("Harry Potter y la camara secreta"),
    Pelicula("Harry Potter y la piedra filosofal"),
    Audiolibro("Harry Potter y el prisionero de Azkaban"),
    Libro("Harry Potter y el caliz de fuego"),
    Pelicula("Harry Potter y la orden del fenix")
]

#se recorre la lista echa de obras y se imprime y reproduce
for obra in obras: 
    if (obra, Imprimible): #si es de la clase Imprimible
        obra.imprimir() #se imprime
    elif (obra, Reproducible): #Y si es de la clase Reproducible
        obra.reproducir() #reproducimos
    else: #Si no, se muestra este mensaje
        print("No se puede reproducir ni imprimir") 